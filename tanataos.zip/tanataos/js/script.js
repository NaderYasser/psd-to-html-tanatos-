/*globa; $, alert. console*/
$(document).ready(function() {
  
$(function (){

  'use strict';

  $('html').niceScroll({
      
      cursorcolor:'#f7600e',
      cursorwidth:10,
      cursorborder:'1px solid #f7600e'          

  });



  
  //change header height
  $('.header').height($(window).height());



  // scroll to features
  $('.header .arrow i').click(function() {
    $('html , body').animate({

       scrollTop:$('.features').offset().top
      
    },800);
  
  });


$('.header .hire').click(function() {
  $('html , body').animate({

       scrollTop:$('.our-team').offset().top
      
    },800);
});


$('.header .work').click(function() {
  $('html , body').animate({

       scrollTop:$('.our-work').offset().top
      
    },800);
});


  //show hidden items from our work
  $('.show-more').click(function() {
    $('.our-work .hidden').fadeIn(2000)
       });




    //testimonials
    var  rightArrow = $('.fa-angle-right');
      var   leftArrow =  $('.fa-angle-left');
   function checkclients(){

    $('.client:first').hasClass('active') ? leftArrow.fadeOut() : leftArrow.fadeIn();
    $('.client:last').hasClass('active') ? rightArrow.fadeOut() : rightArrow.fadeIn();
   }

   checkclients();
  

$('.testimonials i').click(function() {
  if ($(this).hasClass('fa-angle-right')) {
    
    

    $('.testimonials .active').fadeOut('100', function() {
      $(this).removeClass('active').next('.client').addClass('active').fadeIn();
      checkclients();
    });
  } else{
    $('.testimonials .active').fadeOut('100', function() {
      $(this).removeClass('active').prev('.client').addClass('active').fadeIn();
      checkclients();
    });
  }
});


});







});


$(window).load(function() {
  $('.loading-screen').fadeOut(1000);
  $('body').css('overflow', 'auto');
});